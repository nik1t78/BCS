import React, { useState, useEffect } from "react";
import { User, Meeting } from "../types";
import { getMeetings, getUsersForDisplay } from "../store-api";
import { occursOn, withDate } from "../utils/recurrence";
import FreeRoomsWidget from "./FreeRoomsWidget";
import { icsAPI } from "../api/client";

interface DashboardProps {
  user: User;
  onNavigate: (page: string) => void;
  /** Клик по свободному слоту в виджете «Свободные залы» → переход к созданию ВКС */
  onBookSlot?: (roomName: string, startTime: string, endTime: string, date: string) => void;
}

const toDateKey = (d: Date): string =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

export default function Dashboard({ user, onNavigate, onBookSlot }: DashboardProps) {
  const [meetings, setMeetings] = useState<Meeting[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [currentTime, setCurrentTime] = useState(new Date());
  // В одно время может быть несколько конференций — храним все «следующие» (с тем же датой/временем старта)
  const [nextMeetings, setNextMeetings] = useState<Meeting[]>([]);
  const [countdown, setCountdown] = useState("");
  // Экспорт «Мой календарь ВКС» в .ics
  const [icsLoading, setIcsLoading] = useState(false);

  const handleDownloadIcs = async () => {
    setIcsLoading(true);
    try {
      const blob = await icsAPI.download();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "vks-my-schedule.ics";
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error("ICS export error:", e);
      alert("Не удалось сформировать файл .ics");
    } finally {
      setIcsLoading(false);
    }
  };

  useEffect(() => {
    const loadData = async () => {
      try {
        const [m, u] = await Promise.all([getMeetings(), getUsersForDisplay(user.role)]);
        setMeetings(m);
        setUsers(u);
      } catch (error) {
        console.error("Error loading dashboard:", error);
      }
    };
    loadData();

    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    const dataTimer = setInterval(loadData, 30000); // Обновляем каждые 30 секунд

    return () => {
      clearInterval(timer);
      clearInterval(dataTimer);
    };
  }, []);

  // API возвращает id числами, user.id — строка: сравниваем через Number
  const hasAccessTo = (m: Meeting) =>
    Number(m.organizerId) === Number(user.id) || (m.participants ?? []).some((p) => Number(p) === Number(user.id));

  // На главной («Обзор») обычный пользователь видит ТОЛЬКО свои ВКС —
  // организованные им или где он участник. Все остальные конференции —
  // в разделе «Расписание». Админ/модератор видят всё.
  const visibleMeetings =
    user.role === "admin" || user.role === "moderator"
      ? meetings
      : meetings.filter((m) => hasAccessTo(m));

  useEffect(() => {
    const today = toDateKey(currentTime);
    const now = currentTime.toTimeString().slice(0, 5);

    const upcoming = visibleMeetings
      .filter((m) => {
        if (m.status === "cancelled" || m.status === "completed") return false;
        if (m.date > today) return true;
        if (m.date === today && m.startTime > now) return true;
        return false;
      })
      .sort((a, b) => (a.date !== b.date ? a.date.localeCompare(b.date) : a.startTime.localeCompare(b.startTime)));

    // Берём все конференции, совпадающие по дате и времени старта с ближайшей —
    // в одно время может быть несколько конференций.
    const first = upcoming[0] || null;
    const simultaneous = first ? upcoming.filter((m) => m.date === first.date && m.startTime === first.startTime) : [];
    setNextMeetings(simultaneous);

    if (first) {
      const targetDate = new Date(`${first.date}T${first.startTime}`);
      const diff = targetDate.getTime() - currentTime.getTime();
      if (diff > 0) {
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diff % (1000 * 60)) / 1000);
        setCountdown(`${hours}ч ${minutes}м ${seconds}с`);
      }
    }
  }, [currentTime, visibleMeetings]);

  const todayMeetings = visibleMeetings.filter((m) => m.date === toDateKey(currentTime));
  const getUserName = (id: string) => users.find((u) => Number(u.id) === Number(id))?.name || "Неизвестный";

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800 border-red-200";
      case "medium":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "low":
        return "bg-green-100 text-green-800 border-green-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  return (
    <div className="space-y-6">
      {/* Welcome */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl p-6 text-white">
        <h2 className="text-2xl font-bold">Добро пожаловать, {user.name}!</h2>
        <p className="text-blue-100 mt-1">
          {currentTime.toLocaleDateString("ru-RU", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
        </p>
      </div>

      {/* Свободные залы — в самом верху, сразу под приветствием */}
      <FreeRoomsWidget onPickSlot={onBookSlot} />

      {/* Stats — нули показываем прочерком, чтобы не мозолили глаза */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm">
          <p className="text-sm text-gray-500 dark:text-gray-400">Сегодня</p>
          <p className={`text-2xl font-bold ${todayMeetings.length ? "text-gray-800 dark:text-gray-100" : "text-gray-300 dark:text-gray-600"}`}>
            {todayMeetings.length || "—"}
          </p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm">
          <p className="text-sm text-gray-500 dark:text-gray-400">Всего</p>
          <p className={`text-2xl font-bold ${visibleMeetings.length ? "text-gray-800 dark:text-gray-100" : "text-gray-300 dark:text-gray-600"}`}>
            {visibleMeetings.length || "—"}
          </p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm">
          <p className="text-sm text-gray-500 dark:text-gray-400">Организовано</p>
          <p className={`text-2xl font-bold ${visibleMeetings.filter((m) => Number(m.organizerId) === Number(user.id)).length ? "text-gray-800 dark:text-gray-100" : "text-gray-300 dark:text-gray-600"}`}>
            {visibleMeetings.filter((m) => Number(m.organizerId) === Number(user.id)).length || "—"}
          </p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm">
          <p className="text-sm text-gray-500 dark:text-gray-400">Высокий приоритет</p>
          <p className={`text-2xl font-bold ${visibleMeetings.filter((m) => m.priority === "high").length ? "text-gray-800 dark:text-gray-100" : "text-gray-300 dark:text-gray-600"}`}>
            {visibleMeetings.filter((m) => m.priority === "high").length || "—"}
          </p>
        </div>
      </div>

      {/* Next Meeting(s) — в одно время может быть несколько конференций */}
      {nextMeetings.length > 0 &&
        (() => {
          const multiple = nextMeetings.length > 1;

          return (
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border-2 border-blue-200 dark:border-blue-800 p-6">
              <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-4">
                <i className="fas fa-arrow-right text-blue-500 mr-2"></i>
                {multiple ? `Следующие конференции (${nextMeetings.length})` : "Следующая конференция"}
              </h2>

              <div className={multiple ? "space-y-6" : ""}>
                {nextMeetings.map((nextMeeting, idx) => {
                  const canSeeDetails = user.role === "admin" || user.role === "moderator" || hasAccessTo(nextMeeting);

                  return (
                    <div
                      key={nextMeeting.id}
                      className={
                        multiple ? "pb-6 border-b border-gray-200 dark:border-gray-700 last:pb-0 last:border-b-0" : ""
                      }
                    >
                      {multiple && (
                        <p className="text-sm font-semibold text-blue-600 dark:text-blue-400 mb-2">
                          Конференция {idx + 1} из {nextMeetings.length}
                        </p>
                      )}

                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                        <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                          <p className="text-sm text-blue-600 dark:text-blue-400 font-medium">Название</p>
                          <p className="text-lg font-bold text-gray-800 dark:text-gray-100 mt-1">
                            {canSeeDetails ? nextMeeting.title : "Конференция"}
                          </p>
                        </div>
                        <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-4">
                          <p className="text-sm text-purple-600 dark:text-purple-400 font-medium">Дата и время</p>
                          <p className="text-lg font-bold text-gray-800 dark:text-gray-100 mt-1">
                            {new Date(nextMeeting.date).toLocaleDateString("ru-RU")}
                          </p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            {nextMeeting.startTime} - {nextMeeting.endTime}
                          </p>
                        </div>
                        <div className="bg-emerald-50 dark:bg-emerald-900/20 rounded-lg p-4">
                          <p className="text-sm text-emerald-600 dark:text-emerald-400 font-medium">До начала</p>
                          <p className="text-lg font-bold text-gray-800 dark:text-gray-100 mt-1">{countdown}</p>
                        </div>
                        <div className="bg-orange-50 dark:bg-orange-900/20 rounded-lg p-4">
                          <p className="text-sm text-orange-600 dark:text-orange-400 font-medium">Место</p>
                          <p className="text-lg font-bold text-gray-800 dark:text-gray-100 mt-1">
                            {canSeeDetails ? nextMeeting.room || "Онлайн" : "Скрыто"}
                          </p>
                        </div>
                      </div>

                      {canSeeDetails && (
                        <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 mb-4">
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                              <p className="text-sm text-gray-600 dark:text-gray-400 font-medium">Организатор</p>
                              <p className="text-gray-800 dark:text-gray-100">{getUserName(nextMeeting.organizerId)}</p>
                            </div>
                            <div>
                              <p className="text-sm text-gray-600 dark:text-gray-400 font-medium">Участники</p>
                              <p className="text-gray-800 dark:text-gray-100">{nextMeeting.participants.length} чел.</p>
                            </div>
                            <div>
                              <p className="text-sm text-gray-600 dark:text-gray-400 font-medium">Кабинет</p>
                              <p className="text-gray-800 dark:text-gray-100 font-semibold">
                                {nextMeeting.room ? `📍 ${nextMeeting.room}` : "🌐 Онлайн"}
                              </p>
                            </div>
                          </div>
                        </div>
                      )}

                      {nextMeeting.link ? (
                        <a
                          href={nextMeeting.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium"
                        >
                          <i className="fas fa-video mr-2"></i>
                          Подключиться к конференции
                        </a>
                      ) : (
                        <button
                          disabled
                          className="bg-gray-400 text-white px-6 py-3 rounded-lg font-medium cursor-not-allowed"
                        >
                          <i className="fas fa-video mr-2"></i>
                          Ссылка не указана
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })()}

      {/* Today's Schedule */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
        <h2 className="text-lg font-bold text-gray-800 dark:text-gray-100 mb-4">
          <i className="fas fa-calendar-day text-purple-500 mr-2"></i>
          Сегодня{todayMeetings.length > 0 ? ` (${todayMeetings.length})` : ""}
        </h2>
        {todayMeetings.length === 0 ? (
          <p className="text-center text-gray-400 py-8">Нет конференций на сегодня</p>
        ) : (
          <div className="space-y-3">
            {todayMeetings
              .sort((a, b) => a.startTime.localeCompare(b.startTime))
              .map((meeting) => {
                const canSeeDetails = user.role === "admin" || user.role === "moderator" || hasAccessTo(meeting);

                return (
                  <div key={meeting.id} className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-bold text-gray-800 dark:text-gray-100">
                          {canSeeDetails ? meeting.title : "Конференция"}
                        </h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                          {meeting.startTime} - {meeting.endTime}
                          {canSeeDetails && meeting.room && <> • {meeting.room}</>}
                          {!canSeeDetails && <> • Место скрыто</>}
                        </p>
                        {canSeeDetails && (
                          <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">
                            Организатор: {getUserName(meeting.organizerId)}
                          </p>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        {meeting.link && (
                          <a
                            href={meeting.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="bg-blue-600 text-white px-3 py-1.5 rounded-lg text-sm hover:bg-blue-700 transition-colors"
                          >
                            <i className="fas fa-video mr-1"></i>Войти
                          </a>
                        )}
                        <span
                          className={`px-2 py-1 rounded text-xs font-medium border ${getPriorityColor(meeting.priority)}`}
                        >
                          {meeting.priority === "high"
                            ? "Высокий"
                            : meeting.priority === "medium"
                              ? "Средний"
                              : "Низкий"}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
        )}
      </div>

      {/* Быстрые действия: экспорт календаря (.ics) */}
      <div className="bg-white dark:bg-slate-800 rounded-xl shadow p-4 flex flex-col justify-between">
        <div>
          <h3 className="font-semibold text-gray-800 dark:text-gray-100 mb-2">
            <i className="fas fa-calendar-minus mr-2 text-blue-600" aria-hidden="true"></i>
            Мой календарь ВКС
          </h3>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Скачайте файл .ics со своими встречами (название, время, комната, описание)
            и добавьте его в Outlook, Яндекс.Календарь или Google Calendar — расписание
            будет видно даже вне системы.
          </p>
        </div>
        <button
          onClick={handleDownloadIcs}
          disabled={icsLoading}
          className="mt-3 self-start bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700 transition-colors disabled:opacity-50"
        >
          {icsLoading ? (
            <><i className="fas fa-circle-notch fa-spin mr-1"></i> Формирование…</>
          ) : (
            <><i className="fas fa-download mr-1"></i> Скачать .ics</>
          )}
        </button>
      </div>
    </div>
  );
}
